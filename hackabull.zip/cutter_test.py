from PIL import Image, ImageDraw

def cut():
    # Load the image
    img = Image.open("resources\pic0.jpg")

    # Define the center point and radius of the circular region
    a, b = img.size[0] / 2, img.size[1] / 2
    r = 250

    # Create a mask with the circular region filled in white
    mask = Image.new('L', img.size, 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse((a-r, b-r, a+r, b+r), fill=255)

    # Crop the image using the mask
    cropped_img = Image.composite(img, Image.new('RGB', img.size, (255, 255, 255)), mask)

    # Display the cropped image
    cropped_img.save('resources\pic1.jpg')