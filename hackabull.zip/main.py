import io
import os
from playsound import playsound
from google.cloud import texttospeech
import random
from vision import *
from voice import *

def most_recent_file(folder_path, file_extension):
    import os
    # Get a list of all files in the folder
    all_files = os.listdir(folder_path)

    # Filter the list of files to only include files with the specified extension
    matching_files = [file for file in all_files if file.endswith(file_extension)]

    # Get the path of the most recent file
    most_recent_file = max(matching_files, key=lambda x: os.path.getctime(os.path.join(folder_path, x)))

    # Return the path of the most recent file
    return os.path.join(folder_path, most_recent_file)

general_idea(most_recent_file(r'C:\Users\cesar\OneDrive\Imágenes\Álbum de cámara','.jpg'))

thing1 =""
phrases_f = [f"In front of you, there is a {thing1}", f"You are seeing a {thing1}", f"in your line of sight there is a {thing1}", 
f"A {thing1} is right in front of you", f"You are facing a {thing1}", f"Directly in front of you, there is a {thing1}"]
voiceline_infront = random.choice(phrases_f)



phrase_g = f"Overall, the main features of your environment are: {labels_2}"


run_quickstart(phrase_g,6)