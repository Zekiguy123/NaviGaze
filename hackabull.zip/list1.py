from voice import *
import random
from playsound import playsound
from vision import *


thing1 = ""

phrases_f = [f"In front of you, there is a {thing1}", f"You are seeing a {thing1}", f"in your line of sight there is a {thing1}", 
f"A {thing1} is right in front of you", f"You are facing a {thing1}", f"Directly in front of you, there is a {thing1}"]
voiceline_infront = random.choice(phrases_f)



phrase_g = f"Overall, the main features of your environment are: {labels_2}"


